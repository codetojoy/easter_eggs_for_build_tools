Readme Linux

$Id: readme_linux.txt,v 1.3 2004/04/27 11:08:37 unsaved Exp $
Query CVS for revision history.

It is recommended to run the shell scripts(from /bin and /demo) from the 
console, as you will not to be able see any messages from the desktop.
You should set the env variable $JAVA_HOME before running any of the sripts,
or you can use the -jdkhome switch instead to specify the JDK.

See the UNIX Quick Start chapter of the Hsqldb User Guide about how to use
the UNIX init script 'hsqldb'.
